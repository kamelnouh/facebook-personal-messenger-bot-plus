# ملف الجلسة AppState

ضع بيانات AppState التي تملكها بنفسك في `cookies/appstate.json` بصيغة JSON array.
هذا الملف ليس مضمّنًا مع المشروع لحماية حسابك. لا تشارك الجلسة أو ترفعها إلى GitHub.

مثال الشكل فقط موجود في `appstate.example.json` وهو ليس صالحًا لتسجيل الدخول.

module.exports = { name: "id", aliases: ["ايدي"], description: "معرّفات المرسل والمحادثة",
  async execute(ctx) { await ctx.reply(`🆔 Thread ID: ${ctx.event.threadID}\nSender ID: ${ctx.event.senderID || "غير متاح"}`); }
};

module.exports = { name: "prefix", aliases: ["البادئة"], description: "عرض بادئة الأوامر",
  async execute(ctx) { await ctx.reply(`🔧 بادئة الأوامر الحالية: ${ctx.config.prefix}`); }
};

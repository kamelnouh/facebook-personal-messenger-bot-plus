const { isAdmin } = require("../utils/permissions");
module.exports = { name: "admin", aliases: ["مسؤول"], description: "عرض حالة صلاحياتك",
  async execute(ctx) { await ctx.reply(isAdmin(ctx.event.senderID, ctx.config) ? "✅ أنت ضمن قائمة مسؤولي البوت." : "ℹ️ أنت لست ضمن قائمة مسؤولي البوت."); }
};

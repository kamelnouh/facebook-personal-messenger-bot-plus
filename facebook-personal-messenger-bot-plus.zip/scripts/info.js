module.exports = { name: "info", aliases: ["معلومات"], description: "معلومات الرسالة الحالية",
  async execute(ctx) {
    await ctx.reply(`ℹ️ معلومات الرسالة\nنوع الحدث: ${ctx.event.type}\nالمحادثة: ${ctx.event.threadID}\nالمرسل: ${ctx.event.senderID || "غير متاح"}\nالوقت: ${new Date().toLocaleString("ar-DZ", { timeZone: ctx.config.timezone || "Africa/Algiers" })}`);
  }
};

module.exports = { name: "choose", aliases: ["اختار"], description: "اختيار عشوائي من الخيارات",
  async execute(ctx) {
    const choices = ctx.args.join(" ").split("|").map((x) => x.trim()).filter(Boolean);
    if (choices.length < 2) return ctx.reply(`الاستخدام: ${ctx.config.prefix}choose تفاح | موز | برتقال`);
    await ctx.reply(`🎲 الاختيار: ${choices[Math.floor(Math.random() * choices.length)]}`);
  }
};

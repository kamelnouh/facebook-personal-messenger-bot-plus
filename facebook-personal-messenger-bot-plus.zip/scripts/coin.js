module.exports = { name: "coin", aliases: ["عملة"], description: "رمي قطعة نقدية",
  async execute(ctx) { await ctx.reply(Math.random() < 0.5 ? "🪙 صورة!" : "🪙 كتابة!"); }
};

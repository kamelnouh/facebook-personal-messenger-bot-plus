module.exports = { name: "count", aliases: ["احصاء"], description: "حساب الكلمات والحروف",
  async execute(ctx) {
    const s = ctx.args.join(" ");
    if (!s) return ctx.reply(`الاستخدام: ${ctx.config.prefix}count نص`);
    await ctx.reply(`🔢 الحروف: ${Array.from(s).length}\nالكلمات: ${s.trim().split(/\s+/).filter(Boolean).length}`);
  }
};

module.exports = { name: "ping", aliases: ["بنق"], description: "اختبار الاستجابة",
  async execute(ctx) { await ctx.reply("🏓 Pong! البوت يستجيب."); }
};

module.exports = { name: "whoami", aliases: ["من_انا"], description: "عرض معرّفك",
  async execute(ctx) { await ctx.reply(`معرّف حسابك في هذه المحادثة: ${ctx.event.senderID || "غير متاح"}`); }
};

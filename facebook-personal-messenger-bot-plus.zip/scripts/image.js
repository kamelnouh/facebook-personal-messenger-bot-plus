module.exports = { name: "image", aliases: ["صورة"], description: "إرسال صورة محلية من المشروع",
  async execute(ctx) {
    const file = ctx.args[0];
    if (!file) return ctx.reply(`الاستخدام: ${ctx.config.prefix}image media/photo.jpg`);
    if (file.includes("..") || require("node:path").isAbsolute(file)) return ctx.reply("❌ مسار الملف غير مسموح.");
    await ctx.replyFile(file, ctx.args.slice(1).join(" "));
  }
};

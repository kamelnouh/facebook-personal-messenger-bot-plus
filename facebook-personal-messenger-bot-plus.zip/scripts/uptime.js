const { duration } = require("../utils/format");
module.exports = { name: "uptime", aliases: ["مدة"], description: "مدة تشغيل البوت",
  async execute(ctx) { await ctx.reply(`⏱️ مدة التشغيل: ${duration(ctx.uptimeMs)}`); }
};

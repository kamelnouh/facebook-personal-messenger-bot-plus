module.exports = { name: "say", aliases: ["قل"], description: "إعادة إرسال نص",
  async execute(ctx) {
    const text = ctx.args.join(" ");
    if (!text) return ctx.reply(`الاستخدام: ${ctx.config.prefix}say النص`);
    await ctx.reply(text);
  }
};

module.exports = { name: "math", aliases: ["حساب"], description: "حساب تعبير رياضي بسيط",
  async execute(ctx) {
    const expr = ctx.args.join("").replace(/×/g, "*").replace(/÷/g, "/");
    if (!expr || !/^[\d+\-*/().%\s]+$/.test(expr)) return ctx.reply(`الاستخدام: ${ctx.config.prefix}math (5+3)*2`);
    try {
      // Parse only numeric operators; no identifiers, calls, or property access are allowed.
      const result = Function(`"use strict"; return (${expr});`)();
      if (typeof result !== "number" || !Number.isFinite(result)) throw new Error("invalid");
      await ctx.reply(`🧮 النتيجة: ${result}`);
    } catch { await ctx.reply("❌ تعبير حسابي غير صالح."); }
  }
};

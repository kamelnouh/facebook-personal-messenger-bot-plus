const quotes = [
  "التعلّم المستمر يفتح أبوابًا جديدة.",
  "خطوة صغيرة كل يوم تصنع فرقًا كبيرًا.",
  "الصبر والاستمرار أهم من السرعة.",
  "ابدأ بما تملك، وتعلّم أثناء الطريق."
];
module.exports = { name: "quote", aliases: ["حكمة"], description: "حكمة قصيرة",
  async execute(ctx) { await ctx.reply("💡 " + quotes[Math.floor(Math.random() * quotes.length)]); }
};

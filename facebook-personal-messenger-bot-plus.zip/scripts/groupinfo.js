module.exports = { name: "groupinfo", aliases: ["معلومات_القروب"], description: "معلومات المحادثة المتاحة",
  async execute(ctx) {
    ctx.api.getThreadInfo(ctx.event.threadID, (err, info) => {
      if (err || !info) return ctx.reply("تعذر جلب معلومات المحادثة عبر المكتبة.");
      const participants = Array.isArray(info.participantIDs) ? info.participantIDs.length : "غير متاح";
      return ctx.reply(`👥 الاسم: ${info.threadName || "بدون اسم"}\n🆔 Thread ID: ${ctx.event.threadID}\n👤 عدد المشاركين: ${participants}\n📌 نوعها: ${participants === "غير متاح" ? "غير معروف" : "مجموعة"}`);
    });
  }
};

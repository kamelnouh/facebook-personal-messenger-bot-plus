module.exports = { name: "botinfo", aliases: ["معلومات_البوت"], description: "معلومات عن البوت",
  async execute(ctx) {
    const { duration } = require("../utils/format");
    await ctx.reply(`🤖 ${ctx.config.botName}\nNode.js: ${process.version}\nمدة التشغيل: ${duration(ctx.uptimeMs)}\nالأوامر تبدأ بـ ${ctx.config.prefix}`);
  }
};

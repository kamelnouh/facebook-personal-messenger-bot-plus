module.exports = { name: "reverse", aliases: ["اعكس"], description: "عكس النص",
  async execute(ctx) {
    const s = ctx.args.join(" ");
    if (!s) return ctx.reply(`الاستخدام: ${ctx.config.prefix}reverse نص`);
    await ctx.reply(Array.from(s).reverse().join(""));
  }
};

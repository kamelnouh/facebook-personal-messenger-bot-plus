module.exports = {
  name: "help", aliases: ["اوامر", "مساعدة"], description: "عرض الأوامر",
  async execute(ctx) {
    const fs = require("node:fs"), path = require("node:path");
    const rows = [];
    for (const f of fs.readdirSync(__dirname).filter((x) => x.endsWith(".js")).sort()) {
      try {
        const c = require(path.join(__dirname, f));
        if (c.name) rows.push(`${ctx.config.prefix}${c.name} — ${c.description || "بدون وصف"}${c.adminOnly ? " [مسؤول]" : ""}`);
      } catch {}
    }
    await ctx.reply("📚 أوامر البوت:\n" + rows.join("\n"));
  }
};

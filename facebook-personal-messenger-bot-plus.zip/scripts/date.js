module.exports = { name: "date", aliases: ["تاريخ", "وقت"], description: "التاريخ والوقت الحاليان",
  async execute(ctx) { await ctx.reply(new Date().toLocaleString("ar-DZ", { timeZone: ctx.config.timezone || "Africa/Algiers", dateStyle: "full", timeStyle: "long" })); }
};

module.exports = { name: "members", aliases: ["الاعضاء"], description: "عدد أعضاء المحادثة",
  async execute(ctx) {
    ctx.api.getThreadInfo(ctx.event.threadID, (err, info) => {
      if (err || !info) return ctx.reply("تعذر جلب الأعضاء.");
      const ids = info.participantIDs || [];
      ctx.reply(`👥 عدد المشاركين: ${ids.length}\n` + ids.slice(0, 30).map((id, i) => `${i + 1}. ${id}`).join("\n") + (ids.length > 30 ? "\n... تم اختصار القائمة" : ""));
    });
  }
};

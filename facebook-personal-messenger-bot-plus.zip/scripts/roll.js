module.exports = { name: "roll", aliases: ["نرد"], description: "رمي نرد",
  async execute(ctx) {
    const n = Number(ctx.args[0] || 6);
    if (!Number.isInteger(n) || n < 2 || n > 100) return ctx.reply(`الاستخدام: ${ctx.config.prefix}roll 6 (من 2 إلى 100)`);
    await ctx.reply(`🎲 النتيجة: ${1 + Math.floor(Math.random() * n)} من ${n}`);
  }
};

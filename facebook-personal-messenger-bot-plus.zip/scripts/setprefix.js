const fs = require("node:fs"), path = require("node:path");
const { isAdmin } = require("../utils/permissions");
module.exports = { name: "setprefix", aliases: ["تغيير_البادئة"], description: "تغيير البادئة (مسؤول فقط)", adminOnly: true,
  async execute(ctx) {
    const prefix = ctx.args[0];
    if (!prefix || prefix.length > 3 || /\s/.test(prefix)) return ctx.reply(`الاستخدام: ${ctx.config.prefix}setprefix !`);
    const file = path.join(__dirname, "..", "config.json");
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    data.prefix = prefix;
    fs.writeFileSync(file, JSON.stringify(data, null, 2) + "\n");
    ctx.config.prefix = prefix;
    await ctx.reply(`✅ تم تغيير البادئة إلى: ${prefix}`);
  }
};

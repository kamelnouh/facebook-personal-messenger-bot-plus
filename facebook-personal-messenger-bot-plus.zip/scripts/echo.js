module.exports = { name: "echo", aliases: ["كرر"], description: "تكرار نص بعدد محدود",
  async execute(ctx) {
    const count = Math.max(1, Math.min(5, Number(ctx.args[0]) || 1));
    const text = ctx.args.slice(1).join(" ");
    if (!text) return ctx.reply(`الاستخدام: ${ctx.config.prefix}echo 3 مرحبا`);
    await ctx.reply(Array.from({ length: count }, () => text).join("\n"));
  }
};

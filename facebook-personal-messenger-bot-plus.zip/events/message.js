"use strict";
const { isAdmin } = require("../utils/permissions");
const { safeText } = require("../utils/format");
const startedAt = Date.now();
const lastUsed = new Map();

async function handleMessage({ api, event, commands, config, logger }) {
  if (event.type !== "message" || !event.threadID || !event.body) return;
  if (config.ignoreSelfMessages && event.senderID && api.getCurrentUserID &&
      String(event.senderID) === String(api.getCurrentUserID())) return;

  const body = safeText(event.body, Number(config.maxMessageLength) || 1800).trim();
  if (!body.startsWith(config.prefix)) return;

  const parts = body.slice(config.prefix.length).trim().split(/\s+/);
  const commandName = (parts.shift() || "").toLowerCase();
  if (!commandName) return;
  const command = commands.get(commandName);
  if (!command) return;

  const senderID = String(event.senderID || "");
  const cooldownMs = Math.max(0, Number(config.cooldownMs) || 0);
  const key = `${senderID}:${command.name}`;
  const now = Date.now();
  if (!isAdmin(senderID, config) && cooldownMs && now - (lastUsed.get(key) || 0) < cooldownMs) return;
  lastUsed.set(key, now);

  if (command.adminOnly && !isAdmin(senderID, config)) {
    await api.sendMessage("⛔ هذا الأمر مخصص للمسؤول.", event.threadID);
    return;
  }

  const ctx = {
    api, event, args: parts, config, logger,
    isAdmin: isAdmin(senderID, config),
    uptimeMs: now - startedAt,
    reply: (text) => api.sendMessage(safeText(text, Number(config.maxMessageLength) || 1800), event.threadID),
    replyFile: (relativePath, caption) => {
      const path = require("node:path");
      const fs = require("node:fs");
      const base = path.resolve(__dirname, "..");
      const full = path.resolve(base, relativePath);
      if (!full.startsWith(base + path.sep)) return Promise.reject(new Error("مسار غير مسموح"));
      if (!fs.existsSync(full) || !fs.statSync(full).isFile()) {
        return api.sendMessage(`❌ الملف غير موجود: ${relativePath}`, event.threadID);
      }
      const payload = { attachment: fs.createReadStream(full) };
      if (caption) payload.body = caption;
      return api.sendMessage(payload, event.threadID);
    }
  };

  try {
    await command.execute(ctx);
    logger.info(`command=${command.name} sender=${senderID || "unknown"} thread=${event.threadID}`);
  } catch (error) {
    logger.error(`command=${command.name}: ${error.stack || error}`);
    await ctx.reply("حدث خطأ أثناء تنفيذ الأمر. راجع سجل التشغيل.");
  }
}
module.exports = { handleMessage };

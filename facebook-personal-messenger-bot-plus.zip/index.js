"use strict";

// Entry point used by Replit. bot.js remains available as a compatibility wrapper.
require("./bot");

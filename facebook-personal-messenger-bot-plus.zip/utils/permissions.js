"use strict";
function isAdmin(senderID, config) {
  return Array.isArray(config.adminIDs) && config.adminIDs.map(String).includes(String(senderID));
}
module.exports = { isAdmin };

"use strict";
const fs = require("node:fs");
const path = require("node:path");

function createLogger() {
  const logDir = path.join(__dirname, "..", "logs");
  fs.mkdirSync(logDir, { recursive: true });
  const file = path.join(logDir, `${new Date().toISOString().slice(0, 10)}.log`);
  function write(level, message) {
    const line = `[${new Date().toISOString()}] [${level}] ${String(message)}\n`;
    process.stdout.write(line);
    try { fs.appendFileSync(file, line); } catch {}
  }
  return {
    info: (m) => write("INFO", m),
    warn: (m) => write("WARN", m),
    error: (m) => write("ERROR", m)
  };
}
module.exports = { createLogger };

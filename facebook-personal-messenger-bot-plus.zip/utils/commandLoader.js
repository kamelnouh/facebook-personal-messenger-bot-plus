"use strict";
const fs = require("node:fs");
const path = require("node:path");

function loadCommands(directory) {
  const commands = new Map();
  fs.mkdirSync(directory, { recursive: true });
  for (const file of fs.readdirSync(directory).filter((f) => f.endsWith(".js")).sort()) {
    const full = path.join(directory, file);
    try {
      delete require.cache[require.resolve(full)];
      const command = require(full);
      if (!command || !command.name || typeof command.execute !== "function") {
        console.warn(`[commands] تجاهل ${file}: يلزم name و execute(ctx).`);
        continue;
      }
      commands.set(String(command.name).toLowerCase(), command);
      for (const alias of command.aliases || []) commands.set(String(alias).toLowerCase(), command);
    } catch (error) {
      console.error(`[commands] خطأ تحميل ${file}: ${error.message}`);
    }
  }
  return commands;
}
module.exports = { loadCommands };

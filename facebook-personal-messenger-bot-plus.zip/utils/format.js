"use strict";
function duration(ms) {
  const sec = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return [d ? `${d} يوم` : null, h ? `${h} ساعة` : null, m ? `${m} دقيقة` : null, `${s} ثانية`].filter(Boolean).join("، ");
}
function safeText(value, max = 1500) {
  return String(value ?? "").replace(/\u0000/g, "").slice(0, max);
}
module.exports = { duration, safeText };

# Facebook Personal Messenger Bot Plus — Replit

مشروع Node.js منظّم بمدخل `index.js`، مع `bot.js` لمنطق التشغيل، وملفات أوامر مستقلة داخل `scripts/`.

## التشغيل
1. ارفع الملفات إلى Replit من نوع Node.js.
2. في Shell نفّذ `npm install`.
3. أنشئ `cookies/appstate.json` وضع AppState الذي تملكه بصيغة JSON array.
4. نفّذ `npm start`.

ملف `cookies/appstate.json` غير موجود عمدًا في الحزمة. لا تضع الجلسة في المحادثة أو في GitHub.
`npm run dev` يشغّل وضع مراقبة الملفات إن كان مدعومًا في بيئتك.

## الأوامر
`!help`, `!ping`, `!say`, `!uptime`, `!id`, `!info`, `!groupinfo`, `!members`,
`!date`, `!math`, `!choose`, `!reverse`, `!count`, `!image`, `!prefix`, `!botinfo`,
`!admin`, `!setprefix`, `!whoami`, `!coin`, `!roll`, `!quote`, `!echo`.

يمكنك تعديل البادئة من `config.json` أو باستخدام `!setprefix` بعد إضافة معرّفك إلى `adminIDs`.
مثال:
```json
"adminIDs": ["YOUR_FACEBOOK_USER_ID"]
```

## إضافة أمر
أنشئ `scripts/hello.js`:
```js
module.exports = {
  name: "hello",
  aliases: ["مرحبا"],
  description: "تحية",
  async execute(ctx) {
    await ctx.reply("أهلاً!");
  }
};
```
ثم أعد تشغيل Repl.

## حدود وتوافق
يعتمد المشروع على مكتبة غير رسمية تتعامل مع Messenger عبر جلسة حساب شخصي. واجهة المكتبة قد تتغير أو تفشل في المصادقة؛ هذا المشروع لم يُختبر داخل حسابك أو Replit الفعلي. بعض وظائف مثل تغيير صورة الملف الشخصي أو صورة المجموعة أو الـ Bio قد لا تكون مدعومة.
استخدم حسابًا تملكه، ولا تستخدم البوت للإزعاج أو الإرسال الجماعي. إذا انكشف AppState، ألغِ الجلسات النشطة من إعدادات Facebook.

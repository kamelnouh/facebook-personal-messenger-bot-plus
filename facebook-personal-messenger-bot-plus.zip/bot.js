"use strict";

const fs = require("node:fs");
const path = require("node:path");
const login = require("@dongdev/fca-unofficial");
const config = require("./config.json");
const { loadCommands } = require("./utils/commandLoader");
const { createLogger } = require("./utils/logger");
const { handleMessage } = require("./events/message");

const logger = createLogger();
const appStatePath = path.join(__dirname, "cookies", "appstate.json");

function exitWithHelp(message) {
  logger.error(message);
  process.exitCode = 1;
}

if (!fs.existsSync(appStatePath)) {
  exitWithHelp("ملف cookies/appstate.json غير موجود. أنشئه وضع AppState الخاص بك داخله.");
} else {
  let appState;
  try {
    appState = JSON.parse(fs.readFileSync(appStatePath, "utf8"));
    if (!Array.isArray(appState) || appState.length === 0 ||
        appState.some((item) => !item || typeof item !== "object" || !item.key || item.value === undefined)) {
      throw new Error("يجب أن يكون الملف JSON array من عناصر كوكيز تحتوي key و value.");
    }
  } catch (error) {
    exitWithHelp(`تعذر قراءة AppState: ${error.message}`);
  }

  if (appState) {
    const commands = loadCommands(path.join(__dirname, "scripts"));
    logger.info(`تم تحميل ${commands.size} أمر/اسم مستعار.`);
    try {
      login({ appState }, (error, api) => {
        if (error || !api) {
          logger.error("فشل تسجيل الدخول. تحقق من صلاحية AppState وتوافق المكتبة.");
          if (error) logger.error(error.message || String(error));
          process.exitCode = 1;
          return;
        }

        try {
          api.setOptions({ listenEvents: true, selfListen: false, autoReconnect: true });
        } catch (e) {
          logger.warn(`تعذر ضبط بعض الخيارات: ${e.message}`);
        }

        logger.info("تم إنشاء جلسة Messenger؛ بدء الاستماع للرسائل.");
        api.listenMqtt((listenError, event) => {
          if (listenError) {
            logger.error(`خطأ استقبال: ${listenError.message || listenError}`);
            return;
          }
          if (!event) return;
          handleMessage({ api, event, commands, config, logger }).catch((e) => {
            logger.error(`خطأ معالجة حدث: ${e.stack || e}`);
          });
        });
      });
    } catch (error) {
      exitWithHelp(`تعذر تشغيل مكتبة Messenger: ${error.stack || error}`);
    }
  }
}
